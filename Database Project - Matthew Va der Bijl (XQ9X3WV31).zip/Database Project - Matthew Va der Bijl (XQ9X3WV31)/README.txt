Database Design Concepts Project (ITDA211)
Bachelor of Science in Information Technology

Semester 1/2017
Year 2
Submission date 08 May

This folder is my submision for my DA project. It contains:

 * Document containing screenshots (Database Design Concepts Project - Matthew Van der Bijl (XQ9X3WV31).pdf);
 * The exported database (Database Export - Matthew Van der Bijl (XQ9X3WV31).sql);
 * The SQL statements used to create the database (SQL statements - Matthew Van der Bijl - xq9x3wv31.sql);
 * ERD of the project (Database Proect ERD - Matthew Van der Bijl (XQ9X3WV31).jpg);
 * The project specifications (ITDA211 - Project - Specification (V1.0).pdf); and
 * This README file (README.txt)

Matthew Van der Bijl - XQ9X3WV31
07/05/2017
